Prosper Loan Data Exploration
This data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others. This data dictionary explains the variables in the data set. The project objective is not expected to explore all of the variables in the dataset! But focus on only exploration on about 10-15 of them.

Summary of Findings
The majority of borrowers have a rate between 0.1 to 0.2 and less likely to be 0.4 or 0.1 and there is no observation to be higher than 0.4 or 0.0
Most of loans is worthy of payment in 36 month (3 years) to 40 month
It seems that people with income range above 250000 is tend to have loans worth to pay in 36 month
Most of employees have an income range between 50000 to 750000
Most of current loans borrowers have an income range between 50000 to 75000
The loans extremely depend on the income range and employment status 
While the term increase the amount of loans increase (3 year is a enough period)
Key summary
I have made univariate visualization about the Employment Status
To deliver which is the most asking for borrowing 
Also made a bar chart for Loan Status to know to the current status of the loans 
And bar chart for Income Range to know which income range the borrowers has 
Made an multivariate visualization to is the the income range affect the term period and the loan amount 


